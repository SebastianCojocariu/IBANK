#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;
#define MAX_CLIENTS	10
#define BUFLEN 256

void error(char *msg)
{
    perror(msg);
    exit(1);
}

typedef struct cont{
	char nume[12];
	char prenume[12];
	char numar_card[7];
	char pin[5];
	char parola[9];
	float sold;
	int stare = 0; //-1 pt blocat,0 pt liber,i>0 inseamna ca e deja conectat clientul de pe "linia" i
}TCont;

typedef struct utilizator{
	char ultimul_numar_card_accesat[7];
	int nr_accesari_ultimul_card;
}TUtilizator;

typedef struct Tranzactie{
	char numar_cont_sursa[7];
	char numar_card_tranzactie[7];
	float suma = -1;
}TTranzactie;

int main(int argc, char *argv[])
{

	 //verificam numarul de argumente.Daca sunt mai putine de 3,returnam un mesaj corespunzator si iesim din program.
	 if (argc < 3) {
         fprintf(stderr,"Usage : %s port\n", argv[0]);
         exit(1);
     }
     //deschidem fisierul cu datele conturilor si stocam informatiile in map-ul conturi
     int dimensiune,i,j,n;
     
	 FILE *in=fopen(argv[2],"r");

     //numarul de conturi din fisier
     fscanf(in,"%d\n",&dimensiune);
      //map in care tinem conturile,sub forma (key,value)->(numar_cont,contul cu numar_cont )
     map<string,TCont> conturi;
     //map in care tinem (key,value)->(i,informatiile din TUtilizator asociate lui i)
     map<int,TUtilizator> users;
     //map in care tinem (key,value)->(i,informatiile din TTranzactie referitoare la tranzactia pe care urmeaza sa o faca i)
     map<int,TTranzactie> tranzactie;
     //map in care tinem (i,i) si semnifica faptul ca fd=i e conectat la server
     map<int,int> users_conectati;
    
     //populare conturi
     for(i=0;i<dimensiune;i++){
     	TCont cont;
     	fscanf(in,"%s %s %s %s %s %f\n",cont.nume,cont.prenume,cont.numar_card,cont.pin,cont.parola,&cont.sold);
     	conturi.insert(make_pair(cont.numar_card,cont));
     }
     
     //socketi
     int sockfd, udp, newsockfd;
     char buffer[BUFLEN];
     struct sockaddr_in serv_addr, client_address;
     struct sockaddr_in station,from;
 	    
     
     fd_set read_fds;	//multimea de citire folosita in select()
     fd_set tmp_fds;	//multime folosita temporar 
     int fdmax;		//valoare maxima file descriptor din multimea read_fds

     

     //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
     FD_ZERO(&read_fds);
     FD_ZERO(&tmp_fds);

     
     //apelam functia socket atat pentru socketul de TCP,cat si pentru UDP
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     udp = socket(AF_INET,SOCK_DGRAM,0);
     if (sockfd < 0 || udp < 0){ 
        printf("IBANK> -10 : Eroare la apel socket()");
        return -1;
     }

     memset((char *) &serv_addr, 0, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;	// foloseste adresa IP a masinii
     serv_addr.sin_port = htons(atoi(argv[1]));
     
     station.sin_family = AF_INET;
     station.sin_addr.s_addr = INADDR_ANY;	// foloseste adresa IP a masinii
     station.sin_port = htons(atoi(argv[1]));
     
     if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr)) < 0) {
     	printf("IBANK> -10 : Eroare la apel bind()");
        return -1;
     }
     if (bind(udp, (struct sockaddr *) &station, sizeof(struct sockaddr)) < 0){
     	printf("IBANK> -10 : Eroare la apel bind()");
        return -1;
     }

     listen(sockfd, MAX_CLIENTS);

     //adaugam noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
     //0 e fd pentru citire de la tastatura
     //udp e fd pentru tratarea cazului de unlock
     FD_SET(sockfd, &read_fds);
     FD_SET(0,&read_fds);
     FD_SET(udp,&read_fds);
     fdmax = sockfd;
     //folosit pentru udp,pentru a separa cazul in care o data apelat unlock de catre client
     //returnez direct un mesaj de eroare(nu exista nr de card,de ex) de cel in care se cere
     //parola secreta.
     int ok=0;

     // main loop
	while (1) {
		tmp_fds = read_fds; 
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1){ 
			printf("IBANK> -10 : Eroare la apel select()");
			return -1;
		}
	
		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {

				//daca citim de la tastatura(se presupune ca poate primi doar quit,orice alta comanda nu va fi procesata)
				if(i == 0){
		            memset(buffer, 0 , BUFLEN);
		            fgets(buffer, BUFLEN-1, stdin);

		            //daca am primit "quit",anuntam toti clienti ca vom inchide si inchidem serverul.
		            if(memcmp(buffer,"quit",4) == 0){
		            	strcpy(buffer,"Serverul se va inchide.Multumim pentru timpul vostru!IBANK va doreste o zi buna!");
		            		map<int,int>::iterator it = users_conectati.begin();
		            		while(it != users_conectati.end()){
			                	n = send(it->second,buffer,strlen(buffer), 0);
			                	
			                	close(it->first);
			                	FD_CLR(it->first, &read_fds);

								it++;
							}
							return 0;
			        }
			    }

				//daca a venit ceva pe acest socket inseamna ca avem o cerere pt a noua conexiunea.
				//Creem aceasta conexiunea cu accept().
				else if (i == sockfd) {
					// a venit ceva pe socketul inactiv(cel cu listen) = o noua conexiune
					// actiunea serverului: accept()
					int size = sizeof(client_address);
					if ((newsockfd = accept(sockfd, (struct sockaddr *)&client_address, (socklen_t *) &size)) == -1) {
						printf("IBANK> -10 : Eroare la apel accept()");
						return -1;
					} 
					else {
						//adaug noul socket intors de accept() la multimea descriptorilor de citire
						users_conectati.insert(make_pair(newsockfd,newsockfd));
						FD_SET(newsockfd, &read_fds);
						if (newsockfd > fdmax) { 
							fdmax = newsockfd;
						}
					}
					printf("Noua conexiune de la %s, port %d, socket_client %d\n ", inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port), newsockfd);
				}

				//daca a venit o cerere referitoare la optiunea de "unlock"
				else if(i == udp){
					//daca suntem la prima "corespondenta" cand se primeste de la receiver "unlock"
						int size = sizeof(from);
						recvfrom(udp,buffer,256,0,(struct sockaddr *) &from,(socklen_t*) &size);
						//printf("%s\n",buffer);

						//daca am primit un mesaj care incepe cu "unlock"
						if(memcmp(buffer,"unlock",6) == 0){
							//nu exista acel numar de card
							if(conturi.count(buffer+7) <= 0){
								strcpy(buffer,"UNLOCK> -4 : Numar card inexistent");
							}
							//daca cardul respectiv nu e blocat
							else if(conturi.find(buffer+7)->second.stare !=-1)
								strcpy(buffer,"UNLOCK> -6 : Operatie esuata");
							//daca exista numarul de card si contul aferent este blocat
							else{
								ok=1;
								strcpy(buffer,"UNLOCK> Trimite parola secreta");
							}

							sendto(udp,buffer,256,0,(struct sockaddr *) &from,size);
						}
						//cazul cand serverul se asteapta sa primeasca parola secreta
						else{
							char nr_card[7];
							char parola[9];
							strcpy(parola,buffer+7);
							memcpy(nr_card,buffer,6);
							nr_card[6]='\0';

							//daca parola secreta e corecta
							if(strcmp(conturi.find(nr_card)->second.parola,parola) != 0){
								strcpy(buffer,"UNLOCK> -7 : Deblocare esuata");
							}
							else{
								//facem contul liber din nou
								conturi.find(nr_card)->second.stare = 0;
								strcpy(buffer,"UNLOCK> Card deblocat");
							}

							sendto(udp,buffer,256,0,(struct sockaddr *) &from,size);

						}
				}
					
				//am primit cereri de la clienti
				else {

					memset(buffer, 0, BUFLEN);
					n = recv(i, buffer, sizeof(buffer), 0);
					//printf("%s\n",buffer);
					if (n <= 0) {
						printf("%s\n",buffer);
						if (n == 0) {
							//conexiunea s-a inchis
							printf("IBANK> Socket %d hung up\n", i);
						} 
						close(i); 
						FD_CLR(i, &read_fds); // scoatem din multimea de citire socketul pe care 
					}
					  
					
					 //cazul 1--------------------login-----------------
						else if(memcmp(buffer,"login",5) == 0){	
								char numar_card[7];
								char pin[5];
								memcpy(numar_card,buffer+6,6);
								numar_card[6]='\0';
								memcpy(pin,buffer+13,4);
								pin[4]='\0';

								//daca nu avem nicio informatie avand cheia i,inseram una 
								if(users.count(i) <= 0){
									TUtilizator utilizator;
									memcpy(utilizator.ultimul_numar_card_accesat,numar_card,7);
									utilizator.nr_accesari_ultimul_card=1;
									users.insert(make_pair(i,utilizator));
								}
								//daca exista o informatie cu cheia i,insa are ultimul_numar_card_accesat != numar_card primit
								else if(memcmp(users.find(i)->second.ultimul_numar_card_accesat,numar_card,6) != 0){
									memcpy(users.find(i)->second.ultimul_numar_card_accesat,numar_card,7); 
									users.find(i)->second.nr_accesari_ultimul_card=1;
								}
								//daca e acelasi numar de card,incrementam numarul de accesari
								else 
									users.find(i)->second.nr_accesari_ultimul_card++;

								//verificam sa existe numarul de card
								if(conturi.count(numar_card) <=0){
									strcpy(buffer,"IBANK> -4 : Numar de card inexistent");
									send(i,buffer,strlen(buffer),0);
								}
								//verificam sa nu fie deja deschisa o sesiune pt acest cont
								else if(conturi.find(numar_card)->second.stare > 0){
									strcpy(buffer,"IBANK> -2 : Sesiune deja deschisa");
									send(i,buffer,strlen(buffer),0);

								}
								//verificam sa nu fie blocat
								else if(conturi.find(numar_card)->second.stare == -1 ){
										strcpy(buffer,"IBANK> -5 : Card blocat");
										send(i,buffer,strlen(buffer),0);
								}
								//verificam daca pinul introdus se potriveste cu pinul contului accesat
								//daca e gresit
								else if(memcmp(pin,conturi.find(numar_card)->second.pin,4) != 0){
										

											//daca avem deja 3 incercari de logare consecutive gresite,blocam cardul
											if(users.find(i)->second.nr_accesari_ultimul_card == 3){
												strcpy(buffer,"IBANK> -5 : Card blocat");
												send(i,buffer,strlen(buffer),0);
												conturi.find(numar_card)->second.stare = -1;
												//resetam numarul de incercari la 0
												users.find(i)->second.nr_accesari_ultimul_card = 0;
											}
											
											else{
												strcpy(buffer,"IBANK> -3 : Pin gresit");
												send(i,buffer,strlen(buffer),0);
											}
								}
								
								
								//daca e corect pinul
								else{
										conturi.find(numar_card)->second.stare = i;
										memcpy(users.find(i)->second.ultimul_numar_card_accesat,numar_card,7);
										//resetam nr_accesari la 0
										users.find(i)->second.nr_accesari_ultimul_card=0;
										
										
										sprintf(buffer,"IBANK> Welcome %s %s",conturi.find(numar_card)->second.nume,conturi.find(numar_card)->second.prenume);
										send(i,buffer,strlen(buffer),0);
								}

						}

						//cazul 2--------------logout---------------------------
						else if(memcmp(buffer,"logout",6) == 0){
							//reactualizam starea contului din care se face logout la 0(adica e liber)
							conturi.find(users.find(i)->second.ultimul_numar_card_accesat)->second.stare = 0;	
							strcpy(buffer,"IBANK> Clientul a fost deconectat");
							send(i,buffer,strlen(buffer),0);

						}

						//cazul 3 --------------listsold----------------------
						else if(memcmp(buffer,"listsold",8) == 0){
							float sold = conturi.find(users.find(i)->second.ultimul_numar_card_accesat)->second.sold;
							sprintf(buffer,"IBANK> : %0.2f",sold);
							send(i,buffer,strlen(buffer),0);
						}
						
						//cazul 4------------------transfer--------------------
						else if(memcmp(buffer,"transfer",8) == 0){
							char numar_card[7];
							float suma;
							memcpy(numar_card,buffer+9,6);
							numar_card[6] = '\0';
							suma = atof(buffer+16);

							//daca nu exista contul respectiv
							if(conturi.count(numar_card) <= 0){
								strcpy(buffer,"IBANK> -4 : Numar de card inexistent");
								send(i,buffer,strlen(buffer),0);
							}
							//daca incercam sa transferam o suma mai mare decat ce avem in soldul contului curent
							else if(suma > conturi.find(users.find(i)->second.ultimul_numar_card_accesat)->second.sold){
								strcpy(buffer,"IBANK> -8 : Fonduri insuficiente");
								send(i,buffer,strlen(buffer),0);
							}

							//daca putem realiza transferul
							else{
								//daca nu exista cheia i in map-ul tranzactie o adaugam,setand campurile corespunzator
								if(tranzactie.count(i) <= 0){
									TTranzactie aux;
									memcpy(aux.numar_cont_sursa,users.find(i)->second.ultimul_numar_card_accesat,7);
									memcpy(aux.numar_card_tranzactie,numar_card,7);
									aux.suma = suma;
									tranzactie.insert(make_pair(i,aux));
								}
								//daca exista,actualizam in-place;
								else{
									memcpy(tranzactie.find(i)->second.numar_cont_sursa,users.find(i)->second.ultimul_numar_card_accesat,7);
									memcpy(tranzactie.find(i)->second.numar_card_tranzactie,numar_card,7);
									tranzactie.find(i)->second.suma = suma;
								}
 								//cazul suma e intreaga
								if((int)suma == suma)
										sprintf(buffer,"IBANK> Transfer %d catre %s %s? [y/n]",(int)suma,conturi.find(numar_card)->second.nume,conturi.find(numar_card)->second.prenume);
								//cazul cand suma e float
								else 
									sprintf(buffer,"IBANK> Transfer %0.2f catre %s %s? [y/n]",suma,conturi.find(numar_card)->second.nume,conturi.find(numar_card)->second.prenume);
								
								send(i,buffer,strlen(buffer),0);
							}
						}
						//daca primim confirmare si exista o tranzactie cu cheia i,transferam banii
						else if(memcmp(buffer,"y",1) == 0 && tranzactie.count(i) >0 && tranzactie.find(i)->second.suma >0){
							int suma = tranzactie.find(i)->second.suma;
							conturi.find(tranzactie.find(i)->second.numar_card_tranzactie)->second.sold  += suma;
							conturi.find(users.find(i)->second.ultimul_numar_card_accesat)->second.sold  -= suma; 

							//resetam soldul tranzactie[i]
							tranzactie.erase(i);
							//tranzactie.find(i)->second.suma = -1;

							strcpy(buffer,"IBANK> Transfer realizat cu succes");
							send(i,buffer,strlen(buffer),0);

						}
						//daca nu primim 'y' si exista o tranzactie cu cheia i ,stergem tranzactia si nu efectuam transferul.
						else if(memcmp(buffer,"y",1) !=0 && tranzactie.count(i) >0 &&tranzactie.find(i)->second.suma > 0){
							//stergem perechea avand cheia i map-ul tranzactie
							tranzactie.erase(i);

							strcpy(buffer,"IBANK> -9 : Operatie anulata");
							send(i,buffer,strlen(buffer),0);
						}

						//daca primim quit
						else if(memcmp(buffer,"quit",4) == 0){
							//trebuie sa stergem toate datele care il aveau pe i
							if(users.count(i) > 0){
								conturi.find(users.find(i)->second.ultimul_numar_card_accesat)->second.stare = 0;
							}
							tranzactie.erase(i);
							users.erase(i);
							//printf("Am delogat clientul %d\n",i);
							users_conectati.erase(i);
							close(i); 
							FD_CLR(i, &read_fds);
						}
					
					}
		

				} 
			}
		}


     close(sockfd);
     return 0; 
}


