#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
using namespace std;

#define BUFLEN 256

void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    //0 daca nu e conectat la cont,respectiv 1 daca e conectat la un cont
    int conectat = 0;
    //1 daca ni se cere parola secreta pt udp
    int ok=0;
    char nume_fisier[30];
    //fisierul de log.
    sprintf(nume_fisier,"client-%d.log",getpid());
    FILE *out = fopen(nume_fisier,"w");
    int sockfd,udp,n;
    struct sockaddr_in serv_addr,station,from;
    struct hostent *server;
    char ultimul_card_conectat[7];
    char buffer[BUFLEN];

    if (argc < 3) {
       fprintf(stderr,"Usage %s server_address server_port\n", argv[0]);
       exit(0);
    }  
    
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0){
       printf("IBANK> -10 : Eroare la apel socket()");
       return -1;
    }
    udp = socket(AF_INET,SOCK_DGRAM,0);
    if (udp < 0){
       printf("IBANK> -10 : Eroare la apel socket()");
       return -1;
    }
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &serv_addr.sin_addr);
    station.sin_family = AF_INET;
    station.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &station.sin_addr);
    
    
    if (connect(sockfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0) {
        printf("IBANK> -10 : Eroare la apel connect()");
       return -1;
    }
    
    fd_set read_fds;   //multimea de citire folosita in select()
    fd_set tmp_fds;
    FD_ZERO(&read_fds);
    FD_ZERO(&tmp_fds);
    int fdmax;
    FD_SET(0, &read_fds);
    FD_SET(sockfd, &read_fds);
    FD_SET(udp,&read_fds);
    fdmax = sockfd;

    while(1){

        tmp_fds = read_fds; 
        if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1){
            printf("IBANK> -10 : Eroare la apel select()");
                    return -1;
        } 

        memset(buffer, 0 , BUFLEN);

        if (FD_ISSET(0, &tmp_fds)){

            memset(buffer, 0 , BUFLEN);
            fgets(buffer, BUFLEN-1, stdin);
            fprintf(out,"%s",buffer);

            if(memcmp(buffer,"quit",4) == 0){
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0) {
                    printf("IBANK> -10 : Eroare la apel send()");
                    return -1;
                }
                return 0;
                 
            }
            //daca primim unlock
            else if(memcmp(buffer,"unlock",6) == 0 || ok==1){
                int size = sizeof(from);
                
                if(ok == 0){
                    memcpy(buffer+7,ultimul_card_conectat,7);
                
                    sendto(udp,buffer,256,0,(struct sockaddr*) &station,size);
                    recvfrom(udp,buffer,256,0,(struct sockaddr*) &from,(socklen_t*) &size);
                    fprintf(out, "%s\n",buffer);
                    printf("%s\n",buffer);
                    if(memcmp(buffer,"UNLOCK> Trimite parola secreta",15) == 0)
                        ok=1;
                    
                }
                //daca ok==1 inseamna ca serverul ne-a cerut parola secreta.Trimitem parola
                else if(ok==1){
                    char parola_secreta[9];
                    strcpy(parola_secreta,buffer);
                    parola_secreta[strlen(parola_secreta)-1] = '\0';
                    memcpy(buffer,ultimul_card_conectat,6);
                    buffer[6] = ' ';
                    memcpy(buffer+7,parola_secreta,strlen(parola_secreta));
                    buffer[strlen(buffer)] = '\0';
                    sendto(udp,buffer,256,0,(struct sockaddr*) &station,size);
                    recvfrom(udp,buffer,256,0,(struct sockaddr*) &from,(socklen_t*) &size);
                    fprintf(out, "%s\n",buffer);
                    printf("%s\n",buffer);
                    ok=0;

                }
            }

            //daca nu suntem conectati si nu am introdus o comanda de login
            else if(memcmp(buffer,"login",5) != 0 && conectat == 0){
                printf("-1 : Clientul nu este autentificat\n");
            }
            //altfel,daca suntem deja conectati si incercam un login
            else if(memcmp(buffer,"login",5) == 0 && conectat == 1){
                printf("-2 : Sesiune deja deschisa\n");
            }
            //altfel,facem un login
            else if(memcmp(buffer,"login",5) == 0){
                memcpy(ultimul_card_conectat,buffer+6,6);
                ultimul_card_conectat[6]='\0';
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0){
                    printf("IBANK> -10 : Eroare la apel send()");
                    return -1;
                }
            }

            else if(memcmp(buffer,"unlock",6) != 0){
                n = send(sockfd,buffer,strlen(buffer), 0);
                if (n < 0){ 
                    printf("IBANK> -10 : Eroare la apel send()");
                    return -1;
                }
            }

            //daca incercam sa transferam o suma negativa de bani.TRebuie analizat din
            //trimitem unlock pe udp
        
            
        }

        else if (FD_ISSET(sockfd, &tmp_fds)) {

            if ((n = recv(sockfd, buffer, sizeof(buffer), 0)) <= 0) {
               return 0;
            } 
            else { //recv intoarce >0
                buffer[n] = '\0';
                printf("%s\n",buffer);
                fprintf(out, "%s\n",buffer);
                //daca primim acel fragment de mesaj inseamna ca serverul ne-a conectat la cont
                if(memcmp(buffer,"IBANK> Welcome",14) == 0)
                    conectat = 1;
                else if(memcmp(buffer,"IBANK> Clientul a fost deconectat",15) == 0){
                    conectat = 0;
                }
            }
        }

        memset(buffer, 0 , BUFLEN);

    }
    return 0;
}


